package com.Anplay

import com.lagradost.cloudstream3.extractors.Chillx


class AnimesagaStream : Chillx() {
    override val name = "AnimesagaStream"
    override val mainUrl = "https://stream.animesagas.com"
}